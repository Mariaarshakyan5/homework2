﻿using System;

public class CustomDictionary
{
    private string[] keys;
    private string[] values;
    private int count;

    public CustomDictionary(int size)
    {
        keys = new string[size];
        values = new string[size];
        count = 0;
    }

    public void Add(string key, string value)
    {
        if (count >= keys.Length)
        {
            Console.WriteLine("Dictionary is full!");
            return;
        }
        keys[count] = key;
        values[count] = value;
        count++;
    }

    public string Get(string key)
    {
        for (int i = 0; i < count; i++)
        {
            if (keys[i] == key)
            {
                return values[i];
            }
        }
        return null; // Key not found
    }

    public void SortKeys()
    {
        QuickSort(keys, 0, count - 1);
    }

    private void QuickSort(string[] array, int low, int high)
    {
        if (low < high)
        {
            int pivotIndex = Partition(array, low, high);
            QuickSort(array, low, pivotIndex - 1);
            QuickSort(array, pivotIndex + 1, high);
        }
    }

    private int Partition(string[] array, int low, int high)
    {
        string pivot = array[high];
        int i = low - 1;

        for (int j = low; j < high; j++)
        {
            if (string.Compare(array[j], pivot) < 0)
            {
                i++;
                Swap(array, i, j);
            }
        }
        Swap(array, i + 1, high);
        return i + 1;
    }

    private void Swap(string[] array, int i, int j)
    {
        string temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    public void Print()
    {
        for (int i = 0; i < count; i++)
        {
            Console.WriteLine($"Key: {keys[i]}, Value: {values[i]}");
        }
    }
}

public class Program
{
    public static void Main()
    {
        CustomDictionary myDict = new CustomDictionary(10);
        myDict.Add("banan", "A fruit");
        myDict.Add("tandz", "Another fruit");
        myDict.Add("xndzor", "best fruit");

        Console.WriteLine("Before sorting:");
        myDict.Print();

        myDict.SortKeys();

        Console.WriteLine("\nAfter sorting:");
        myDict.Print();
    }
}
